"""Immutable generation identity and selected-world checkpoint provenance."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from cot_navigation.config import to_plain
from cot_navigation.data.shards import SCHEMA_VERSION, atomic_json, file_sha256


GENERATOR_VERSION = 3


def digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def prepare_generation(cfg) -> dict:
    """Fail before writing when an existing root belongs to a different dataset.

    Worker count and audit settings do not change content. Chunk size changes
    the storage layout and therefore requires a new root when resuming.
    """
    raw = to_plain(cfg)
    excluded = {"root", "workers", "chunk_size", "audit_fraction", "max_attempts", "graph_shape", "graph_seed"}
    semantic = {k: v for k, v in raw.items() if k not in excluded}
    identity = {
        "schema_version": SCHEMA_VERSION,
        "generator_version": GENERATOR_VERSION,
        "semantic": semantic,
    }
    expected = {**identity, "fingerprint": digest(identity), "chunk_size": cfg.chunk_size}
    root = Path(cfg.root)
    signature = root / "generation.json"
    if signature.exists():
        old = json.loads(signature.read_text())
        if old != expected:
            raise ValueError(f"generation configuration mismatch at {root}; use a new data.root (existing files were not changed)")
    elif root.exists() and any(root.iterdir()):
        raise ValueError(f"unversioned/nonempty data root {root}; use a new root rather than relabeling existing data")
    else:
        root.mkdir(parents=True, exist_ok=True)
        atomic_json(signature, expected)
    return expected


def dataset_fingerprint(root: Path, manifest: dict) -> str:
    """Exclude execution-only manifest fields such as workers and storage path."""
    signature = root / "generation.json"
    if not signature.exists():
        raise ValueError(f"missing generation provenance at {root}; regenerate this legacy dataset in a new root")
    generation = json.loads(signature.read_text())
    if generation["fingerprint"] != manifest.get("generation_fingerprint"):
        raise ValueError(f"manifest/generation fingerprint mismatch at {root}")
    return digest({"generation": generation["fingerprint"], "splits": manifest.get("splits")})


def world_fingerprint(root: Path) -> str:
    """Bind graph, node mapping, knowledge corpus, query splits and selection ids."""
    names = ["graph.npz", "walks.npz", "queries.npz", "balanced_train.npy", "balanced_val.npy", "balanced_test.npy"]
    return digest({name: file_sha256(root / name) for name in names})
